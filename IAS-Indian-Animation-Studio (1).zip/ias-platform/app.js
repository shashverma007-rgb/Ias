(() => {
  const $ = (s) => document.querySelector(s);
  const $$ = (s) => [...document.querySelectorAll(s)];
  const cfg = window.IAS_CONFIG || {};
  const configured = cfg.supabaseUrl?.startsWith("https://") && cfg.supabaseAnonKey && !cfg.supabaseAnonKey.includes("PASTE_");
  const supabase = configured && window.supabase ? window.supabase.createClient(cfg.supabaseUrl, cfg.supabaseAnonKey) : null;
  let authMode = "login", currentUser = null, currentProfile = null, activeGame = null;
  const games = [
    {id:"rivals", title:"RIVALS", category:"Shooter", description:"A fast-paced first-person arena shooter. Enter the arena, sharpen your aim and outplay your rivals.", players:"Arena shooter", image:"assets/rivals.svg", url:"games/rivals/index.html", featured:true, status:"Coming soon"},
    {id:"worlds", title:"IAS Worlds", category:"Adventure", description:"Explore new places, discover hidden paths and take on challenges in a colourful adventure.", players:"Explore & discover", image:"assets/worlds.svg", url:"", status:"Coming soon"},
    {id:"neon", title:"Neon Clash", category:"Action", description:"A bright arcade-inspired action challenge built around quick decisions and quick movement.", players:"Action challenge", image:"assets/neon.svg", url:"", status:"Coming soon"}
  ];
  const recentKey = () => `ias_recent_${currentUser?.id || "guest"}`;
  const safeText = (s) => String(s ?? "").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
  const toast = (msg) => { const el=$("#toast"); el.textContent=msg; el.classList.add("show"); setTimeout(()=>el.classList.remove("show"),3200); };
  $$("[data-year]").forEach(e=>e.textContent=new Date().getFullYear());

  function setAuthMode(mode) {
    authMode=mode;
    $$(".tab").forEach(b=>b.classList.toggle("active",b.dataset.tab===mode));
    $("#auth-title").textContent=mode==="login"?"Welcome back":"Join the IAS universe";
    $("#auth-subtitle").textContent=mode==="login"?"Sign in to continue to IAS.":"Create your IAS player account.";
    $("#email-wrap").classList.toggle("hidden",mode==="login");
    $("#email").required=mode==="signup";
    $("#username-label").textContent=mode==="login"?"Email address":"Username";
    $("#username").type=mode==="login"?"email":"text";
    $("#username").placeholder=mode==="login"?"you@example.com":"Your IAS username";
    $("#username").minLength=mode==="login"?0:3;
    $("#username").maxLength=mode==="login"?254:20;
    $("#auth-submit").innerHTML=mode==="login"?'Sign in <span>→</span>':'Create account <span>→</span>';
    $("#auth-message").textContent="";
    $("#password").autocomplete=mode==="login"?"current-password":"new-password";
  }
  $$(".tab").forEach(b=>b.addEventListener("click",()=>setAuthMode(b.dataset.tab)));

  async function handleAuth(e) {
    e.preventDefault();
    const username=$("#username").value.trim();
    const password=$("#password").value;
    const email=$("#email").value.trim();
    const msg=$("#auth-message"), btn=$("#auth-submit");
    msg.textContent="";
    if(authMode==="signup" && !/^[a-zA-Z0-9_]{3,20}$/.test(username)){msg.textContent="Username must be 3–20 characters (letters, numbers or underscores).";return;}
    if(authMode==="login" && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(username)){msg.textContent="Enter the email address you used to create your account.";return;}
    if(password.length<8){msg.textContent="Use a password with at least 8 characters.";return;}
    if(!supabase){msg.textContent="Account service is not connected yet. Complete the Supabase setup in README.md and config.js.";return;}
    btn.disabled=true; btn.textContent="Please wait…";
    try {
      if(authMode==="signup"){
        const {data,error}=await supabase.auth.signUp({email,password,options:{data:{username}}});
        if(error) throw error;
        if(data.session){await ensureProfile(data.user,username); currentUser=data.user; await enterApp();}
        else msg.textContent="Account created! Check your email to confirm your address, then sign in.";
      } else {
        const {data,error}=await supabase.auth.signInWithPassword({email:username,password});
        if(error) throw error;
        currentUser=data.user; await enterApp();
      }
    } catch(err){msg.textContent=err.message || "Could not complete sign in.";}
    finally{btn.disabled=false;btn.innerHTML=authMode==="login"?'Sign in <span>→</span>':'Create account <span>→</span>';}
  }
  async function ensureProfile(user,username){
    if(!supabase || !user)return;
    const {error}=await supabase.from("profiles").upsert({id:user.id,username:username || user.user_metadata?.username || user.email?.split("@")[0]},{onConflict:"id"});
    if(error) console.error("Profile save:",error.message);
  }
  $("#auth-form").addEventListener("submit",handleAuth);

  async function enterApp(){
    if(!currentUser && supabase){const {data}=await supabase.auth.getUser();currentUser=data.user;}
    if(!currentUser)return;
    let profile={username:currentUser.user_metadata?.username || currentUser.email?.split("@")[0] || "Player"};
    if(supabase){
      const {data}=await supabase.from("profiles").select("username,created_at").eq("id",currentUser.id).maybeSingle();
      if(data) profile={...profile,...data};
    }
    currentProfile=profile;
    $("#auth-screen").classList.add("hidden");$("#app-shell").classList.remove("hidden");
    const name=profile.username;
    ["#side-username","#top-username","#profile-name"].forEach(s=>$(s).textContent=name);
    ["#side-avatar","#top-avatar","#profile-avatar"].forEach(s=>$(s).textContent=name.slice(0,1).toUpperCase());
    $("#profile-email").textContent=currentUser.email || "";
    $("#profile-created").textContent=profile.created_at?`IAS member since ${new Date(profile.created_at).toLocaleDateString()}`:"IAS player account";
    renderGames();showView("home");
  }
  async function signOut(){
    if(supabase) await supabase.auth.signOut();
    currentUser=null;currentProfile=null;activeGame=null;
    $("#app-shell").classList.add("hidden");$("#auth-screen").classList.remove("hidden");
    $("#auth-form").reset();setAuthMode("login");
  }
  $("#signout-btn").addEventListener("click",signOut);$("#profile-signout").addEventListener("click",signOut);

  function showView(view){
    $$(".page-view").forEach(v=>v.classList.add("hidden"));
    const el=$(`#${view}-view`);if(el)el.classList.remove("hidden");
    $$(".side-link").forEach(b=>b.classList.toggle("active",b.dataset.view===view));
    $("#page-name").textContent=({home:"Home",discover:"Discover games",recent:"Recently played",profile:"My profile",player:"Now playing"})[view]||"Home";
    if(view==="recent")renderRecent();
  }
  $$("[data-view]").forEach(b=>b.addEventListener("click",()=>showView(b.dataset.view)));
  $$("[data-filter]").forEach(b=>b.addEventListener("click",()=>{showView("discover");$("#category-filter").value=b.dataset.filter;renderDiscover();}));

  function gameCard(g){
    return `<article class="game-card"><button class="game-cover" data-play="${safeText(g.id)}" style="--cover:url('${safeText(g.image)}')"><img src="${safeText(g.image)}" alt="" loading="lazy"><span class="cover-tag">${safeText(g.category)}</span><span class="cover-play">▶</span></button><div class="game-info"><div><h3>${safeText(g.title)}</h3><p>${safeText(g.description)}</p></div><button class="card-play ${g.url?"":"disabled-play"}" data-play="${safeText(g.id)}" ${g.url?"":"aria-label='Coming soon'"}>${g.url?"PLAY":"SOON"} <span>→</span></button></div></article>`;
  }
  function renderGames(){
    $("#featured-grid").innerHTML=games.filter(g=>g.featured).concat(games.filter(g=>!g.featured).slice(0,2)).map(gameCard).join("");
    renderDiscover();bindPlay();
  }
  function renderDiscover(){
    const q=($("#game-search")?.value||"").toLowerCase(),cat=$("#category-filter")?.value||"All";
    const list=games.filter(g=>(cat==="All"||g.category===cat)&&(`${g.title} ${g.description} ${g.category}`).toLowerCase().includes(q));
    $("#discover-grid").innerHTML=list.map(gameCard).join("");
    $("#empty-games").classList.toggle("hidden",list.length>0);bindPlay();
  }
  $("#game-search").addEventListener("input",renderDiscover);$("#category-filter").addEventListener("change",renderDiscover);
  function bindPlay(){
    $$("[data-play]").forEach(b=>b.addEventListener("click",()=>launchGame(b.dataset.play)));
  }
  function getRecent(){try{return JSON.parse(localStorage.getItem(recentKey())||"[]");}catch{return [];}}
  function addRecent(id){const arr=[id,...getRecent().filter(x=>x!==id)].slice(0,12);localStorage.setItem(recentKey(),JSON.stringify(arr));}
  function renderRecent(){
    const list=getRecent().map(id=>games.find(g=>g.id===id)).filter(Boolean);
    $("#recent-grid").innerHTML=list.map(gameCard).join("");$("#recent-empty").classList.toggle("hidden",list.length>0);bindPlay();
  }
  function launchGame(id){
    const game=games.find(g=>g.id===id);if(!game)return;
    if(!game.url){toast(`${game.title} is not published yet. Add its browser game files to make it playable.`);return;}
    activeGame=game;$("#player-title").textContent=game.title;$("#game-container").innerHTML="";
    const frame=document.createElement("iframe");frame.src=game.url;frame.title=game.title;frame.allow="fullscreen; gamepad; autoplay";frame.allowFullscreen=true;
    $("#game-container").append(frame);addRecent(id);showView("player");
  }
  $("#back-to-games").addEventListener("click",()=>showView("discover"));
  $("#fullscreen-btn").addEventListener("click",()=>{const frame=$("#game-container iframe");if(frame?.requestFullscreen)frame.requestFullscreen();else toast("Fullscreen is not available in this browser.");});

  if(supabase){
    supabase.auth.getSession().then(async({data})=>{if(data.session){currentUser=data.session.user;await enterApp();}});
    supabase.auth.onAuthStateChange((_event,session)=>{if(session?.user){currentUser=session.user;}});
  }
})();