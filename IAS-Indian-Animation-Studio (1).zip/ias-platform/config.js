/*
  IAS backend configuration.
  1) Create a project at https://supabase.com
  2) In Project Settings → API, copy Project URL and anon/public key.
  3) Paste them below. Never put a service_role key in website code.
*/
window.IAS_CONFIG = {
  supabaseUrl: "PASTE_YOUR_SUPABASE_PROJECT_URL_HERE",
  supabaseAnonKey: "PASTE_YOUR_SUPABASE_ANON_PUBLIC_KEY_HERE"
};