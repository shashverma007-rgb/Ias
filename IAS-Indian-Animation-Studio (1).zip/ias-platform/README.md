# IAS — Indian Animation Studio

A static-hosted game discovery platform with real account authentication powered by Supabase. The site is designed for GitHub Pages; account data is stored in Supabase, not in the browser.

## 1. Set up real accounts (required)

1. Create a project at https://supabase.com and wait for it to finish provisioning.
2. In Supabase, open **SQL Editor → New query**.
3. Copy all of `schema.sql` into the editor and click **Run**.
4. Open **Project Settings → API** (or API Keys).
5. Copy the Project URL and the `anon` / publishable public key.
6. Open `config.js` and replace the two placeholder values:
   - `supabaseUrl`
   - `supabaseAnonKey`
7. In Supabase → Authentication → URL Configuration, set:
   - Site URL: `https://YOUR-GITHUB-USERNAME.github.io/palblox/`
   - Add that same URL to Redirect URLs.
8. In Authentication → Providers → Email, decide whether email confirmation should be required. For a public platform, keep confirmation enabled.
9. In Authentication → Rate Limits / Security, retain sensible protections. Never publish a `service_role` or secret key.

### Account sign-in detail
Registration asks for a username, email and password. Supabase uses email + password for secure authentication; the username is saved as the public IAS profile name. Players create an account with a username, email and password. They sign in using their email address and password; their chosen username is displayed as their IAS player name. Username-only sign-in can be added later with a rate-limited server-side lookup function.

## 2. IAS profiles, friends and live RIVALS room

The updated `schema.sql` adds:
- Public player profiles with a saved avatar.
- Friend requests with pending and accepted states.
- Row Level Security rules so players can only create their own requests and accept requests sent to them.

The RIVALS browser game uses Supabase Realtime Broadcast and Presence. Players who launch RIVALS with the same configured IAS backend enter one shared open room. Their simple player avatars and usernames are broadcast while they move. This first multiplayer layer is a shared presence/visual arena: each player still has their own practice targets, score, health and round timer. It is not yet a competitive PvP system, shared damage, matchmaking, voice chat or anti-cheat.

After running the updated `schema.sql`:
1. Open Supabase → Project Settings → API and confirm your public anon/publishable key is in `config.js`.
2. In Supabase → Realtime, make sure Realtime is enabled for the project and Broadcast/Presence channels are allowed by your project settings.
3. Publish the updated website files. Players must use the same IAS website/backend to meet in the same RIVALS room.
4. Create two IAS accounts in separate browsers/devices, add each other as friends, then launch RIVALS in both browsers. Move around to see the other player appear.

## 3. Publish on GitHub Pages

Upload the contents of this folder into the root of your existing `palblox` repository:
- `index.html`
- `styles.css`
- `app.js`
- `config.js`
- `schema.sql`
- `README.md`
- `assets/`
- `games/`

Then go to **Repository → Settings → Pages**:
- Source: Deploy from a branch
- Branch: `main`
- Folder: `/ (root)`
- Save

Your URL will be `https://YOUR-GITHUB-USERNAME.github.io/palblox/`.

## 4. Add a browser game

1. Create a folder such as `games/my-game/`.
2. Put the game's browser entry file at `games/my-game/index.html`.
3. In `app.js`, add a game object to the `games` array:
   `{id:"my-game", title:"My Game", category:"Action", description:"A short description.", players:"Browser game", image:"assets/my-game.svg", url:"games/my-game/index.html"}`
4. Add a matching cover image in `assets/`.
5. Commit and push. The game opens in the IAS embedded browser player.

The game must be an HTML5/browser game. A Roblox experience URL cannot be converted into a playable browser game just by embedding it.

## 5. Important limitations

- GitHub Pages serves static files only. Supabase provides authentication and database services.
- RIVALS is an early shared-room multiplayer prototype: player movement/avatars are live, but hits and scores are not synchronized between players yet.
- The other catalog entries are clearly marked Coming soon until actual playable HTML5 game files are added.
- Some external websites block iframe embedding. Host browser game files within this repository or use a provider that explicitly allows embedding.
- For a production platform with moderation, chat, multiplayer, purchases, parental controls, anti-cheat, and user-generated game uploads, add trusted server-side services and security review before launch.
