Put each browser game's files in its own folder, for example games/rivals/index.html. Then update the games array in app.js with that entry path.
