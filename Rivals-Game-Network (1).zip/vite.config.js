import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

export default defineConfig({
  plugins: [react()],
  // For GitHub Pages, set this to "/YOUR_REPOSITORY_NAME/" if deploying
  // to username.github.io/YOUR_REPOSITORY_NAME. Use "/" for a custom domain.
  base: "/"
});