import { useEffect, useMemo, useState } from "react";
import {
  ArrowRight, Bell, Check, ChevronDown, CircleUserRound, Compass,
  Gamepad2, LogOut, Menu, Search, ShieldCheck, Sparkles, UserRound,
  X, Eye, EyeOff, Plus, Settings, Trophy
} from "lucide-react";
import { games } from "./data/games";
import { isSupabaseConfigured, supabase } from "./lib/supabase";

const initialProfile = { username: "", bio: "", favorite_game: "" };

function App() {
  const [session, setSession] = useState(null);
  const [profile, setProfile] = useState(initialProfile);
  const [authMode, setAuthMode] = useState("signin");
  const [authOpen, setAuthOpen] = useState(false);
  const [profileOpen, setProfileOpen] = useState(false);
  const [selectedGame, setSelectedGame] = useState(null);
  const [query, setQuery] = useState("");
  const [category, setCategory] = useState("All games");
  const [notice, setNotice] = useState("");
  const [mobileMenu, setMobileMenu] = useState(false);
  const [loading, setLoading] = useState(true);
  const [authLoading, setAuthLoading] = useState(false);
  const [authError, setAuthError] = useState("");
  const [authSuccess, setAuthSuccess] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [username, setUsername] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [savedGames, setSavedGames] = useState([]);
  const [showSavedOnly, setShowSavedOnly] = useState(false);

  useEffect(() => {
    if (!supabase) { setLoading(false); return; }
    supabase.auth.getSession().then(({ data }) => {
      setSession(data.session);
      setLoading(false);
    });
    const { data: listener } = supabase.auth.onAuthStateChange((_event, nextSession) => {
      setSession(nextSession);
    });
    return () => listener.subscription.unsubscribe();
  }, []);

  useEffect(() => {
    if (!session?.user || !supabase) {
      setProfile(initialProfile);
      setSavedGames([]);
      return;
    }
    let active = true;
    async function loadUserData() {
      const userId = session.user.id;
      const [{ data: userProfile }, { data: favorites }] = await Promise.all([
        supabase.from("profiles").select("username,bio,favorite_game").eq("id", userId).maybeSingle(),
        supabase.from("favorites").select("game_id").eq("user_id", userId)
      ]);
      if (!active) return;
      if (userProfile) setProfile({ ...initialProfile, ...userProfile });
      else {
        const fallback = (session.user.user_metadata?.username || session.user.email?.split("@")[0] || "player").slice(0, 24);
        setProfile({ ...initialProfile, username: fallback });
      }
      setSavedGames((favorites || []).map((item) => item.game_id));
    }
    loadUserData();
    return () => { active = false; };
  }, [session]);

  const categories = useMemo(() => ["All games", ...new Set(games.map((game) => game.category))], []);
  const filteredGames = useMemo(() => games.filter((game) => {
    const matchesQuery = `${game.title} ${game.subtitle} ${game.category} ${game.description} ${game.tags.join(" ")}`
      .toLowerCase().includes(query.toLowerCase());
    const matchesCategory = category === "All games" || game.category === category;
    const matchesSaved = !showSavedOnly || savedGames.includes(game.id);
    return matchesQuery && matchesCategory && matchesSaved;
  }), [query, category, showSavedOnly, savedGames]);

  function flash(message) {
    setNotice(message);
    window.setTimeout(() => setNotice(""), 3500);
  }

  async function handleAuth(event) {
    event.preventDefault();
    setAuthError("");
    setAuthSuccess("");
    if (!supabase) return;
    setAuthLoading(true);
    try {
      if (authMode === "signup") {
        const cleanUsername = username.trim();
        if (cleanUsername.length < 3) throw new Error("Username must be at least 3 characters.");
        const { data, error } = await supabase.auth.signUp({
          email: email.trim(),
          password,
          options: { data: { username: cleanUsername } }
        });
        if (error) throw error;
        if (data.session) {
          const { error: profileError } = await supabase.from("profiles").upsert({
            id: data.user.id, username: cleanUsername
          });
          if (profileError) throw profileError;
          setAuthOpen(false);
          flash("Welcome to Rivals. Your account is ready.");
        } else {
          setAuthSuccess("Account created. Check your email to confirm it, then sign in.");
        }
      } else {
        const { error } = await supabase.auth.signInWithPassword({ email: email.trim(), password });
        if (error) throw error;
        setAuthOpen(false);
        flash("You are signed in.");
      }
    } catch (error) {
      setAuthError(error.message || "Something went wrong. Please try again.");
    } finally {
      setAuthLoading(false);
    }
  }

  async function signOut() {
    if (supabase) await supabase.auth.signOut();
    setProfileOpen(false);
    flash("You have been signed out.");
  }

  async function toggleFavorite(gameId) {
    if (!session) {
      setAuthMode("signin");
      setAuthOpen(true);
      setAuthError("Sign in to save games to your library.");
      return;
    }
    if (!supabase) return;
    const alreadySaved = savedGames.includes(gameId);
    if (alreadySaved) {
      const { error } = await supabase.from("favorites").delete()
        .eq("user_id", session.user.id).eq("game_id", gameId);
      if (error) { flash(error.message); return; }
      setSavedGames((old) => old.filter((id) => id !== gameId));
      flash("Removed from your library.");
    } else {
      const { error } = await supabase.from("favorites").insert({ user_id: session.user.id, game_id: gameId });
      if (error) { flash(error.message); return; }
      setSavedGames((old) => [...old, gameId]);
      flash("Saved to your library.");
    }
  }

  async function saveProfile(event) {
    event.preventDefault();
    if (!supabase || !session) return;
    const cleanUsername = profile.username.trim();
    if (cleanUsername.length < 3) { flash("Username must be at least 3 characters."); return; }
    const { error } = await supabase.from("profiles").upsert({
      id: session.user.id,
      username: cleanUsername,
      bio: profile.bio.trim().slice(0, 160),
      favorite_game: profile.favorite_game
    });
    if (error) { flash(error.message); return; }
    setProfileOpen(false);
    flash("Profile saved.");
  }

  const currentUser = profile.username || session?.user?.email?.split("@")[0] || "Player";

  return (
    <div className="app-shell">
      <div className="ambient ambient-one" /><div className="ambient ambient-two" />
      <header className="topbar">
        <a className="brand" href="#home" aria-label="Rivals home">
          <span className="brand-mark"><Gamepad2 size={22} strokeWidth={2.5}/></span>
          <span>RIVALS<span className="brand-dot">.</span><small>GAME NETWORK</small></span>
        </a>
        <nav className={`nav-links ${mobileMenu ? "nav-open" : ""}`}>
          <a className="nav-link active" href="#library" onClick={() => setMobileMenu(false)}><Compass size={16}/> Discover</a>
          <button className={`nav-link ${showSavedOnly ? "active" : ""}`} onClick={() => { setShowSavedOnly(!showSavedOnly); setMobileMenu(false); }}><Trophy size={16}/> My library</button>
          <a className="nav-link" href="#about" onClick={() => setMobileMenu(false)}>About</a>
        </nav>
        <div className="top-actions">
          {session ? (
            <button className="profile-button" onClick={() => setProfileOpen(true)}>
              <span className="avatar">{currentUser.slice(0, 1).toUpperCase()}</span>
              <span className="profile-name">{currentUser}</span><ChevronDown size={15}/>
            </button>
          ) : (
            <button className="button button-primary button-small" onClick={() => { setAuthMode("signin"); setAuthOpen(true); }}>
              Sign in <ArrowRight size={15}/>
            </button>
          )}
          <button className="icon-button mobile-toggle" aria-label="Toggle menu" onClick={() => setMobileMenu(!mobileMenu)}>{mobileMenu ? <X/> : <Menu/>}</button>
        </div>
      </header>

      {!isSupabaseConfigured && (
        <div className="setup-banner">
          <ShieldCheck size={18}/>
          <span><strong>Setup required:</strong> connect a Supabase project to enable real accounts and persistent user data. See <code>README.md</code>.</span>
        </div>
      )}

      <main id="home">
        <section className="hero">
          <div className="hero-copy">
            <div className="eyebrow"><span className="live-dot"/> YOUR NEXT MATCH STARTS HERE</div>
            <h1>PLAY MORE.<br/><span>BE MORE.</span></h1>
            <p className="hero-description">Your games. Your crew. Your next obsession. Discover games, build your library, and make this space yours.</p>
            <div className="hero-actions">
              <a className="button button-primary" href="#library">Explore games <ArrowRight size={17}/></a>
              {!session && <button className="button button-ghost" onClick={() => { setAuthMode("signup"); setAuthOpen(true); }}>Create account <UserRound size={17}/></button>}
            </div>
            <div className="hero-trust"><span><Check size={14}/> Personal library</span><span><Check size={14}/> Built for players</span><span><Check size={14}/> Always growing</span></div>
          </div>
          <div className="hero-art" aria-label="Abstract gaming illustration">
            <div className="art-ring ring-one"/><div className="art-ring ring-two"/>
            <div className="art-cross cross-one">+</div><div className="art-cross cross-two">+</div>
            <div className="art-card card-back"><span>PLAYER ONE</span><b>READY?</b><small>NO LIMITS. JUST PLAY.</small></div>
            <div className="art-card card-front">
              <div className="card-topline"><span className="tiny-square"/> FEATURED GAME <span className="card-top-right">001 / 008</span></div>
              <div className="featured-symbol">R<span>!</span></div>
              <div className="featured-bottom"><div><small>ON THE RADAR</small><strong>RIVALS</strong></div><span className="featured-arrow"><ArrowRight/></span></div>
            </div>
            <div className="floating-chip chip-top"><Sparkles size={15}/> LEVEL UP</div>
            <div className="floating-chip chip-bottom"><span className="live-dot"/> GAME ON</div>
          </div>
        </section>

        <section className="stats-row" aria-label="Library overview">
          <div className="stat"><span className="stat-number">{String(games.length).padStart(2, "0")}</span><span className="stat-label">GAMES TO DISCOVER</span></div>
          <div className="stat-divider"/>
          <div className="stat"><span className="stat-number">{String(new Set(games.map(g => g.category)).size).padStart(2, "0")}</span><span className="stat-label">GAME CATEGORIES</span></div>
          <div className="stat-divider"/>
          <div className="stat"><span className="stat-number">{String(savedGames.length).padStart(2, "0")}</span><span className="stat-label">IN YOUR LIBRARY</span></div>
          <div className="stats-note"><span className="live-dot"/> <span>MORE GAMES COMING</span></div>
        </section>

        <section className="library-section" id="library">
          <div className="section-heading">
            <div><div className="eyebrow muted-eyebrow">THE COLLECTION</div><h2>{showSavedOnly ? "YOUR LIBRARY" : "FIND YOUR GAME."}</h2><p>Explore the collection and find what you want to play next.</p></div>
            {showSavedOnly && <button className="text-button" onClick={() => setShowSavedOnly(false)}>View all games <ArrowRight size={15}/></button>}
          </div>
          <div className="library-controls">
            <label className="search-box"><Search size={18}/><input value={query} onChange={e => setQuery(e.target.value)} placeholder="Search games, genres, studios..." aria-label="Search games"/>{query && <button onClick={() => setQuery("")} aria-label="Clear search"><X size={15}/></button>}</label>
            <div className="category-select"><span>FILTER</span><select value={category} onChange={e => setCategory(e.target.value)} aria-label="Filter by category">{categories.map(c => <option key={c}>{c}</option>)}</select><ChevronDown size={15}/></div>
          </div>
          {loading ? <div className="empty-state">Loading your player profile…</div> : filteredGames.length ? (
            <div className="game-grid">
              {filteredGames.map((game, index) => <article className={`game-card accent-${game.accent}`} key={game.id} style={{ "--delay": `${index * 45}ms` }}>
                <button className={`favorite-button ${savedGames.includes(game.id) ? "is-favorite" : ""}`} aria-label={savedGames.includes(game.id) ? "Remove from library" : "Save to library"} onClick={() => toggleFavorite(game.id)}><Trophy size={16} fill={savedGames.includes(game.id) ? "currentColor" : "none"}/></button>
                <button className="game-card-main" onClick={() => setSelectedGame(game)} aria-label={`View ${game.title} details`}>
                  <div className="game-art"><div className="art-grid-lines"/><span className="game-initials">{game.initials}</span><span className="game-art-label">{game.category.toUpperCase()}</span><span className="game-art-index">{String(index + 1).padStart(2, "0")}</span></div>
                  <div className="game-info"><div className="game-meta"><span>{game.subtitle}</span><span className="status-pill">{game.status}</span></div><h3>{game.title}</h3><p>{game.description}</p><div className="tag-row">{game.tags.map(tag => <span className="tag" key={tag}>{tag}</span>)}</div></div>
                </button>
                <div className="game-card-footer"><span><span className="live-dot"/> IN THE COLLECTION</span><button onClick={() => setSelectedGame(game)} className="arrow-button" aria-label={`Open ${game.title}`}><ArrowRight size={18}/></button></div>
              </article>)}
            </div>
          ) : <div className="empty-state"><Gamepad2 size={32}/><h3>No games found</h3><p>Try another search or category.</p><button className="button button-ghost" onClick={() => { setQuery(""); setCategory("All games"); setShowSavedOnly(false); }}>Reset filters</button></div>}
        </section>

        <section className="join-banner" id="about">
          <div className="join-icon"><Gamepad2 size={27}/></div>
          <div className="join-copy"><div className="eyebrow muted-eyebrow">YOUR PLAYER PROFILE</div><h2>MAKE IT YOURS.</h2><p>Create an account to save games and personalize your library across sessions.</p></div>
          {session ? <button className="button button-primary" onClick={() => setProfileOpen(true)}>Edit profile <Settings size={16}/></button> : <button className="button button-primary" onClick={() => { setAuthMode("signup"); setAuthOpen(true); }}>Join the network <ArrowRight size={17}/></button>}
        </section>
      </main>

      <footer className="footer"><a className="brand footer-brand" href="#home"><span className="brand-mark"><Gamepad2 size={18}/></span><span>RIVALS<span className="brand-dot">.</span></span></a><span>BUILT FOR THE LOVE OF PLAY.</span><span>© {new Date().getFullYear()} RIVALS NETWORK</span></footer>

      {notice && <div className="toast"><Check size={17}/>{notice}<button onClick={() => setNotice("")} aria-label="Dismiss"><X size={15}/></button></div>}

      {authOpen && <div className="modal-backdrop" onMouseDown={e => { if (e.target === e.currentTarget) setAuthOpen(false); }}>
        <section className="modal auth-modal" role="dialog" aria-modal="true" aria-labelledby="auth-title">
          <button className="modal-close" onClick={() => setAuthOpen(false)} aria-label="Close"><X/></button>
          <div className="modal-brand"><span className="brand-mark"><Gamepad2 size={23}/></span></div>
          <div className="eyebrow muted-eyebrow">{authMode === "signup" ? "JOIN THE NETWORK" : "WELCOME BACK"}</div>
          <h2 id="auth-title">{authMode === "signup" ? "CREATE YOUR ACCOUNT." : "GOOD TO SEE YOU."}</h2>
          <p className="modal-subtitle">{authMode === "signup" ? "Create your player identity and start building your library." : "Sign in to pick up where you left off."}</p>
          {!isSupabaseConfigured ? <div className="setup-modal-note"><ShieldCheck size={20}/><div><strong>Authentication isn't connected yet.</strong><p>Set up Supabase and add your environment variables using the README instructions. This form will then create real accounts.</p></div></div> : <form onSubmit={handleAuth} className="auth-form">
            {authMode === "signup" && <label>USERNAME<input autoComplete="username" required minLength={3} maxLength={24} value={username} onChange={e => setUsername(e.target.value)} placeholder="Your player name"/></label>}
            <label>EMAIL ADDRESS<input type="email" autoComplete="email" required value={email} onChange={e => setEmail(e.target.value)} placeholder="you@example.com"/></label>
            <label>PASSWORD<div className="password-field"><input type={showPassword ? "text" : "password"} autoComplete={authMode === "signup" ? "new-password" : "current-password"} minLength={8} required value={password} onChange={e => setPassword(e.target.value)} placeholder="At least 8 characters"/><button type="button" onClick={() => setShowPassword(!showPassword)} aria-label={showPassword ? "Hide password" : "Show password"}>{showPassword ? <EyeOff size={17}/> : <Eye size={17}/>}</button></div></label>
            {authError && <p className="form-error">{authError}</p>}{authSuccess && <p className="form-success">{authSuccess}</p>}
            <button className="button button-primary auth-submit" disabled={authLoading}>{authLoading ? "PLEASE WAIT…" : authMode === "signup" ? "CREATE ACCOUNT" : "SIGN IN"} <ArrowRight size={16}/></button>
          </form>}
          <div className="auth-switch">{authMode === "signup" ? "Already have an account?" : "New around here?"} <button onClick={() => { setAuthMode(authMode === "signup" ? "signin" : "signup"); setAuthError(""); setAuthSuccess(""); }}>{authMode === "signup" ? "Sign in" : "Create account"}</button></div>
          <p className="secure-note"><ShieldCheck size={14}/> Your password is handled by Supabase Auth, never stored in your profile table.</p>
        </section>
      </div>}

      {selectedGame && <div className="modal-backdrop" onMouseDown={e => { if (e.target === e.currentTarget) setSelectedGame(null); }}>
        <section className={`modal game-modal accent-${selectedGame.accent}`} role="dialog" aria-modal="true" aria-labelledby="game-title">
          <button className="modal-close" onClick={() => setSelectedGame(null)} aria-label="Close"><X/></button>
          <div className="detail-art"><div className="art-grid-lines"/><span>{selectedGame.initials}</span><small>{selectedGame.category.toUpperCase()}</small></div>
          <div className="eyebrow muted-eyebrow">{selectedGame.subtitle} / {selectedGame.category}</div>
          <h2 id="game-title">{selectedGame.title}</h2><p className="detail-description">{selectedGame.description}</p>
          <div className="tag-row detail-tags">{selectedGame.tags.map(tag => <span className="tag" key={tag}>{tag}</span>)}</div>
          <button className="button button-primary full-button" onClick={() => toggleFavorite(selectedGame.id)}>{savedGames.includes(selectedGame.id) ? <Check size={17}/> : <Plus size={17}/>} {savedGames.includes(selectedGame.id) ? "Saved to your library" : "Add to my library"}</button>
          <p className="detail-note">This catalog is informational. Game ownership and launching are handled by each game's official platform.</p>
        </section>
      </div>}

      {profileOpen && <div className="modal-backdrop" onMouseDown={e => { if (e.target === e.currentTarget) setProfileOpen(false); }}>
        <section className="modal profile-modal" role="dialog" aria-modal="true" aria-labelledby="profile-title">
          <button className="modal-close" onClick={() => setProfileOpen(false)} aria-label="Close"><X/></button>
          <div className="profile-large-avatar">{currentUser.slice(0, 1).toUpperCase()}</div>
          <div className="eyebrow muted-eyebrow">PLAYER SETTINGS</div><h2 id="profile-title">YOUR PROFILE.</h2>
          <p className="modal-subtitle">{session?.user?.email}</p>
          <form className="auth-form" onSubmit={saveProfile}>
            <label>USERNAME<input value={profile.username} onChange={e => setProfile({ ...profile, username: e.target.value })} minLength={3} maxLength={24} required/></label>
            <label>SHORT BIO<input value={profile.bio} onChange={e => setProfile({ ...profile, bio: e.target.value })} maxLength={160} placeholder="What do you play?"/></label>
            <label>FAVOURITE GAME<select value={profile.favorite_game} onChange={e => setProfile({ ...profile, favorite_game: e.target.value })}><option value="">Choose a game</option>{games.map(g => <option key={g.id} value={g.id}>{g.title}</option>)}</select></label>
            <button className="button button-primary auth-submit">Save profile <Check size={16}/></button>
          </form>
          <button className="button button-ghost full-button signout-button" onClick={signOut}><LogOut size={16}/> Sign out</button>
        </section>
      </div>}
    </div>
  );
}

export default App;