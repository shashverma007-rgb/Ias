// Add new games here later. Each game is displayed automatically in the library.
export const games = [
  {
    id: "roblox-rivals",
    title: "RIVALS",
    subtitle: "Roblox",
    category: "FPS",
    status: "Featured",
    accent: "violet",
    description: "A fast-paced first-person shooter focused on quick duels, movement, aim, and competitive rounds. Build your mechanics, learn the maps, and challenge other players.",
    tags: ["Competitive", "FPS", "Multiplayer"],
    initials: "R"
  },
  {
    id: "valorant",
    title: "VALORANT",
    subtitle: "Riot Games",
    category: "Tactical FPS",
    status: "Popular",
    accent: "red",
    description: "A tactical 5v5 shooter where precise gunplay meets agents with distinct abilities. Coordinate with your team, control space, and win rounds through strategy.",
    tags: ["5v5", "Tactical", "Teamwork"],
    initials: "V"
  },
  {
    id: "fortnite",
    title: "FORTNITE",
    subtitle: "Epic Games",
    category: "Battle Royale",
    status: "Popular",
    accent: "blue",
    description: "Drop into a changing island, gather equipment, and outlast opponents. Explore different modes, play with friends, and adapt your strategy as the match develops.",
    tags: ["Battle Royale", "Squads", "Action"],
    initials: "F"
  },
  {
    id: "counter-strike-2",
    title: "COUNTER-STRIKE 2",
    subtitle: "Valve",
    category: "Tactical FPS",
    status: "Competitive",
    accent: "orange",
    description: "A round-based tactical shooter built around teamwork, economy management, map knowledge, and disciplined aim. Attack and defend objectives across competitive maps.",
    tags: ["Tactical", "Competitive", "5v5"],
    initials: "CS"
  },
  {
    id: "apex-legends",
    title: "APEX LEGENDS",
    subtitle: "Respawn Entertainment",
    category: "Hero Shooter",
    status: "Squads",
    accent: "pink",
    description: "A squad-based battle royale with distinctive Legends, movement-heavy combat, and team abilities. Pick a role, communicate with your squad, and fight to become champions.",
    tags: ["Squads", "Movement", "Battle Royale"],
    initials: "A"
  },
  {
    id: "rocket-league",
    title: "ROCKET LEAGUE",
    subtitle: "Psyonix",
    category: "Sports",
    status: "Casual + Ranked",
    accent: "cyan",
    description: "Football meets rocket-powered cars. Master aerial control, rotations, recoveries, and teamwork in quick matches that are easy to start and difficult to master.",
    tags: ["Sports", "Ranked", "Multiplayer"],
    initials: "RL"
  },
  {
    id: "minecraft",
    title: "MINECRAFT",
    subtitle: "Mojang Studios",
    category: "Sandbox",
    status: "Creative",
    accent: "green",
    description: "Explore a block-based world, gather resources, craft tools, build structures, and survive. Play solo or join friends for creative projects and adventures.",
    tags: ["Sandbox", "Creative", "Survival"],
    initials: "M"
  },
  {
    id: "overwatch-2",
    title: "OVERWATCH 2",
    subtitle: "Blizzard",
    category: "Hero Shooter",
    status: "Team-based",
    accent: "gold",
    description: "A team-based hero shooter where heroes bring different weapons, mobility, and abilities. Coordinate team compositions, take objectives, and make decisive plays.",
    tags: ["Heroes", "Objectives", "Teamwork"],
    initials: "O2"
  }
];