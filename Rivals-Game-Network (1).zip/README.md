# Rivals — Game Network

A responsive gaming library built with React + Vite and Supabase Auth/Postgres. It includes real email/password sign-up and sign-in, user profiles, saved games, search, category filters, game detail dialogs, and a seed catalog you can extend.

## Important: this is an app, not a single static HTML page

The frontend can be hosted on GitHub Pages, but real accounts and cross-device saved data require a Supabase project. Do not deploy this as only `index.html`: the React source, styles, package manifest, and build configuration are required.

## 1. Create the Supabase backend

1. Create a project at https://supabase.com/.
2. In the Supabase dashboard, open **SQL Editor**.
3. Run all SQL in `supabase/schema.sql`.
4. Open **Project Settings → API** (or API Keys) and copy the Project URL and publishable/anon key.
5. In **Authentication → URL Configuration**, set your local Site URL during development, then add your final GitHub Pages URL to Redirect URLs.

The app uses Supabase Auth for passwords. Passwords are not stored in the `profiles` table. Row Level Security policies ensure authenticated users can only access their own profile and favorites.

## 2. Configure local development

Install Node.js 20 or newer. Copy `.env.example` to `.env` and fill in the Supabase Project URL and publishable/anon key:

```env
VITE_SUPABASE_URL=https://YOUR_PROJECT_ID.supabase.co
VITE_SUPABASE_ANON_KEY=YOUR_SUPABASE_PUBLISHABLE_OR_ANON_KEY
```

Never put a Supabase `service_role` key in this frontend project. The publishable/anon key is intended for client use when Row Level Security is correctly enabled.

Then run:

```bash
npm install
npm run dev
```

Open the local URL Vite prints in the terminal.

## 3. Deploy on GitHub Pages

GitHub Pages hosts static frontend files, so build the React app before deployment.

1. Push the full project to your GitHub repository.
2. If the repository URL is `https://USERNAME.github.io/REPOSITORY/`, change `base` in `vite.config.js` to `"/REPOSITORY/"` (keep both slashes). If using a custom domain or `USERNAME.github.io` repository, use `"/"`.
3. In your repository, open **Settings → Secrets and variables → Actions → Variables** and add:
   - `VITE_SUPABASE_URL`
   - `VITE_SUPABASE_ANON_KEY`
4. Add a GitHub Actions workflow to build and publish the `dist` folder. GitHub Pages settings should use **GitHub Actions** as the source.
5. Add the final published URL to Supabase Authentication's allowed redirect URLs.

### Example GitHub Actions workflow

Create `.github/workflows/deploy.yml`:

```yaml
name: Deploy Rivals to GitHub Pages
on:
  push:
    branches: [main]
  workflow_dispatch:
permissions:
  contents: read
  pages: write
  id-token: write
concurrency:
  group: pages
  cancel-in-progress: true
jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-node@v4
        with:
          node-version: 20
          cache: npm
      - run: npm install
      - run: npm run build
        env:
          VITE_SUPABASE_URL: ${{ vars.VITE_SUPABASE_URL }}
          VITE_SUPABASE_ANON_KEY: ${{ vars.VITE_SUPABASE_ANON_KEY }}
      - uses: actions/upload-pages-artifact@v3
        with:
          path: dist
  deploy:
    environment:
      name: github-pages
      url: ${{ steps.deployment.outputs.page_url }}
    runs-on: ubuntu-latest
    needs: build
    steps:
      - id: deployment
        uses: actions/deploy-pages@v4
```

Save the workflow as `.github/workflows/deploy.yml`. Set repository **Settings → Pages → Build and deployment → Source** to **GitHub Actions**.

## 4. Add more games later

Edit `src/data/games.js` and add an object using this shape:

```js
{
  id: "unique-game-id",
  title: "GAME NAME",
  subtitle: "Developer or platform",
  category: "Action",
  status: "New",
  accent: "violet",
  description: "A concise description of the game.",
  tags: ["Action", "Multiplayer"],
  initials: "GN"
}
```

Use a unique `id`. Available accent classes: `violet`, `red`, `blue`, `orange`, `pink`, `cyan`, `green`, `gold`. New games automatically appear in search, category filters, details, and the favorite-game profile selector.

## Current functionality

- Real email/password sign-up and sign-in via Supabase Auth
- User profile with username, bio, and favorite game
- Saved games stored in Supabase per user
- Search and category filters
- Responsive layout, accessible labels, reduced-motion support
- Curated starter catalog with game descriptions

## Production checklist

Before opening the site to the public, configure email confirmation and password recovery in Supabase, add a privacy policy and terms appropriate for your project, set rate limits / CAPTCHA if needed, and test signup, email confirmation, login, sign-out, profile updates, and favorites in a separate test account. The app is an independent catalog; game names and trademarks belong to their respective owners.
