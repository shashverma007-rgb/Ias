// Supabase Edge Function: username-login
// Deploy with Supabase CLI. SUPABASE_URL, SUPABASE_ANON_KEY and
// SUPABASE_SERVICE_ROLE_KEY are provided as server-side function secrets.
// Never expose the service role key in browser JavaScript.
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

Deno.serve(async (req) => {
  const headers = {
    "Content-Type": "application/json",
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
    "Access-Control-Allow-Methods": "POST, OPTIONS"
  };
  if (req.method === "OPTIONS") return new Response("ok", { headers });
  if (req.method !== "POST") {
    return new Response(JSON.stringify({ error: "Method not allowed" }), {
      status: 405, headers
    });
  }

  try {
    const { username, password } = await req.json();
    if (typeof username !== "string" || typeof password !== "string" ||
        !/^[a-zA-Z0-9_]{3,20}$/.test(username) || password.length < 8) {
      return new Response(JSON.stringify({ error: "Username or password is incorrect." }), {
        status: 400, headers
      });
    }

    const admin = createClient(
      Deno.env.get("SUPABASE_URL"),
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY"),
      { auth: { persistSession: false, autoRefreshToken: false } }
    );

    // Find the matching username in Auth user metadata. The lookup is server-side.
    let matchedUser = null;
    let page = 1;
    const perPage = 1000;
    while (page <= 20 && !matchedUser) {
      const { data, error } = await admin.auth.admin.listUsers({ page, perPage });
      if (error) throw error;
      matchedUser = data.users.find(
        (u) => (u.user_metadata?.username || "").toLowerCase() === username.toLowerCase()
      ) || null;
      if (data.users.length < perPage) break;
      page++;
    }

    if (!matchedUser?.email) {
      return new Response(JSON.stringify({ error: "Username or password is incorrect." }), {
        status: 401, headers
      });
    }

    // Verify the password through the normal Supabase password grant.
    const verifier = createClient(
      Deno.env.get("SUPABASE_URL"),
      Deno.env.get("SUPABASE_ANON_KEY"),
      { auth: { persistSession: false, autoRefreshToken: false } }
    );
    const { data: loginData, error: loginError } = await verifier.auth.signInWithPassword({
      email: matchedUser.email,
      password
    });
    if (loginError || !loginData.session) {
      return new Response(JSON.stringify({ error: "Username or password is incorrect." }), {
        status: 401, headers
      });
    }

    return new Response(JSON.stringify({
      access_token: loginData.session.access_token,
      refresh_token: loginData.session.refresh_token
    }), { status: 200, headers });
  } catch (_error) {
    return new Response(JSON.stringify({ error: "Login could not be completed. Try again." }), {
      status: 500, headers
    });
  }
});
